Fix: PalmPay account not persisting across page visits
=========================================================
Updated: app/fund/page.tsx

The bug: Paga persisted correctly, but switching to the PalmPay tab always
showed the BVN/NIN verification form again, even after an account had
already been generated once. Cause: the page only checked for an existing
SAVED account on load for Paga - it never checked PalmPay, so clicking
that tab just cleared the display and assumed no account existed yet.

Fix: added a checkExistingAccount() helper that silently asks the backend
"do I already have an account for this channel?" (no identity fields
needed - the backend already returns a saved account immediately
regardless). This now runs both on page load (Paga) and whenever either
tab is clicked. The BVN/NIN form only shows if that check comes back
empty, i.e. genuinely no PalmPay account exists yet.

No backend changes needed - app/api/wallet/fund-neurapay/route.ts already
returned the saved account first, before ever checking identity fields.

HOW TO USE:
1. Upload to repo root in Codespace.
2. unzip -o fix-palmpay-persistence.zip -d . && rm fix-palmpay-persistence.zip
3. npm run dev - generate a PalmPay account, navigate away (e.g. to
   Dashboard), come back to Fund Wallet, click PalmPay tab again - it
   should show the SAME account immediately, no form.
4. git add app/fund/page.tsx
   git commit -m "Fix PalmPay account not persisting across page visits"
   git push
