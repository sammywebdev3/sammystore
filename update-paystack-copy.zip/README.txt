Update copy: Paystack -> NeuraPay wording
==========================================
Updated: app/page.tsx              (landing page "how it works" step)
Updated: app/faq/page.tsx          (3 FAQ answers)
Updated: app/privacy/page.tsx      (payment processing section)
Updated: components/FAQAccordion.tsx (1 FAQ answer)

Just copy/wording changes - no functional/logic changes in this zip.

HOW TO USE:
1. Upload to repo root in Codespace.
2. unzip -o update-paystack-copy.zip -d . && rm update-paystack-copy.zip
3. npm run dev - spot check the landing page, FAQ page, and privacy page.
4. git add app/page.tsx app/faq/page.tsx app/privacy/page.tsx components/FAQAccordion.tsx
   git commit -m "Update copy from Paystack to NeuraPay wording"
   git push
