Bug fixes: broken referral bonus + missing suspended check
=============================================================
Updated: models/Transaction.ts        (adds missing 'referral_bonus' to type enum)
Updated: lib/neurapayCredit.ts        (actually credits the referrer's ₦500)
Updated: app/api/wallet/fund-neurapay/route.ts  (blocks suspended accounts)

BUG #1 - Referral bonus never actually paid out:
  app/referrals/page.tsx promises: "When someone signs up with it and
  makes their first deposit, you get ₦500 credited to your wallet
  automatically." No code anywhere ever created that credit - and even
  if it had, 'referral_bonus' was missing from Transaction's type enum,
  so the write would have thrown a validation error anyway (same class
  of bug already documented for other types in that file).
  Fixed: lib/neurapayCredit.ts now credits the REFERRER ₦500 the moment
  the person they referred completes their first successful deposit -
  same idempotency pattern as the welcome bonus (unique reference per
  referred user, so it can only ever fire once).

BUG #2 - Suspended users could still fund their wallet:
  Every other balance-touching route (checkout, buy numbers, SMM orders)
  blocks suspended accounts - fund-neurapay was the one route that didn't.
  Fixed: now returns 403 "Your account is suspended" like everywhere else.

HOW TO USE:
1. Upload to repo root in Codespace.
2. unzip -o bugfixes-referral-suspended.zip -d .
   rm bugfixes-referral-suspended.zip
3. npm run dev - test with two accounts: sign up account B using account
   A's referral link, fund account B's wallet, confirm account A's
   balance goes up by ₦500.
4. git add models/Transaction.ts lib/neurapayCredit.ts app/api/wallet/fund-neurapay/route.ts
   git commit -m "Fix referral bonus never crediting + block suspended users from funding"
   git push
