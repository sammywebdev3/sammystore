NeuraPay: Persistent Virtual Accounts (fix "new account every visit")
=======================================================================
Updated: models/User.ts                          (stores account per channel)
Updated: app/api/wallet/fund-neurapay/route.ts    (reuses saved account, no re-call to NeuraPay)
Updated: lib/neurapayCredit.ts                    (matches payments by account number, not a per-attempt reference)
Updated: app/fund/page.tsx                        (loads existing account automatically, "Refresh Balance" replaces broken "Check Status")

REMOVED: app/api/wallet/check-neurapay/route.ts
  This route only worked with the old one-account-per-payment model.
  It's now dead code - delete it from your repo (the unzip below
  won't do this for you automatically, since zip can't delete files).

WHAT CHANGED AND WHY:
NeuraPay virtual accounts are permanent per customer - the same account
number should be reused for every transfer, not regenerated each visit.
The old code called NeuraPay's create-account API on every page load,
which is why you kept getting a new account number. Now:
  - First visit: generates ONE account per channel (Paga / PalmPay),
    saves it on the User document.
  - Every visit after: instantly returns the saved account, no API call.
  - Payments are credited by matching the incoming transfer's account
    number to a user, not by pre-creating a "pending" transaction per
    attempt - so the same account can receive money any number of times.
  - The old "I've Made the Transfer - Check Status" button couldn't
    really work under the old model with a persistent account (there's
    no single reference to check per-visit) - replaced with a plain
    "Refresh Balance" button. The webhook remains the real mechanism
    that credits the wallet automatically.

HOW TO USE:
1. Upload this zip to your repo root in Codespace.
2. unzip -o neurapay-persistent-accounts.zip -d . && rm neurapay-persistent-accounts.zip
3. Manually delete the dead route (zip can't delete files for you):
     rm -rf app/api/wallet/check-neurapay
4. npm run dev - test funding again. Leave the page and come back;
   the SAME account number should show up both times.
5. Commit:
     git add models/User.ts app/api/wallet/fund-neurapay/route.ts lib/neurapayCredit.ts app/fund/page.tsx
     git rm -r app/api/wallet/check-neurapay
     git commit -m "Make NeuraPay virtual accounts persistent per user"
     git push
