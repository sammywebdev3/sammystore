import mongoose, { Schema, Document, Model } from 'mongoose';
import * as bcrypt from 'bcryptjs';

export interface IUser extends Document {
  name: string;
  email: string;
  password: string;
  apiKey: string;
  walletBalance: number;
  suspended: boolean;
  suspendReason?: string;
  createdAt: Date;
  updatedAt: Date;
  comparePassword(candidatePassword: string): Promise<boolean>;
}

const UserSchema: Schema<IUser> = new Schema(
  {
    name: { type: String, required: true },
    email: { type: String, required: true, unique: true },
    password: { type: String, required: true },
    apiKey: { type: String, default: '' },
    walletBalance: { type: Number, default: 0 },
    suspended: { type: Boolean, default: false },
    suspendReason: { type: String, default: '' },
  },
  { timestamps: true }
);

// Plain async hook (no `next` callback needed - Mongoose supports this
// directly) so the password is hashed exactly once, right before saving,
// no matter which route creates or updates the user. Callers should always
// pass a PLAIN TEXT password and let this hook hash it - hashing it again
// before calling .create()/.save() would double-hash it and break login.
UserSchema.pre('save', async function () {
  if (!this.isModified('password')) return;
  this.password = await bcrypt.hash(this.password, 10);
});

UserSchema.methods.comparePassword = async function (candidatePassword: string): Promise<boolean> {
  return bcrypt.compare(candidatePassword, this.password);
};

export default (mongoose.models.User as Model<IUser>) || mongoose.model<IUser>('User', UserSchema);
