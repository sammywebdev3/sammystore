import { NextResponse } from 'next/server';
import dbConnect from '@/lib/mongodb';
import User from '@/models/User';
import { getUserId } from '@/lib/auth';

export async function GET(request: Request) {
  await dbConnect();
  const userId = await getUserId(request);
  if (!userId) return NextResponse.json({ success: false, error: 'Please login' }, { status: 401 });

  const user = await User.findById(userId).select('name email apiKey walletBalance createdAt suspended');
  if (!user) return NextResponse.json({ success: false, error: 'User not found' }, { status: 404 });

  return NextResponse.json({
    success: true,
    user: {
      name: user.name,
      email: user.email,
      apiKey: user.apiKey,
      walletBalance: user.walletBalance,
      createdAt: user.createdAt,
      suspended: user.suspended,
    },
  });
}
