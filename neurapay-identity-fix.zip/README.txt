NeuraPay PalmPay fix: correct identity_type value
==================================================
Updated: app/api/wallet/fund-neurapay/route.ts

The earlier version sent identity_type: "BVN" or "NIN", which NeuraPay
rejected ("The selected identity type is invalid"). Per NeuraPay's own
documented request example, identity_type should be the fixed string
"personal" for an individual account owner - the actual BVN/NIN digits
still go in license_number, and the BVN/NIN dropdown in the UI is just
labeling which kind of number the user is entering.

HOW TO USE:
1. Upload to repo root in Codespace.
2. unzip -o neurapay-identity-fix.zip -d . && rm neurapay-identity-fix.zip
3. npm run dev, test PalmPay again.
4. git add app/api/wallet/fund-neurapay/route.ts
   git commit -m "Fix NeuraPay PalmPay identity_type value"
   git push
