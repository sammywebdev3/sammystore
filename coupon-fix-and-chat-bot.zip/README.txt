1) Coupon race-condition fix + 2) AI Live Chat Support Widget
================================================================

PART 1 - Coupon usage-limit race condition
Updated: lib/coupon.ts                    (markCouponRedeemed is now atomic)
Updated: app/api/cart/checkout/route.ts   (claims the redemption BEFORE crediting the discount)

Before: two simultaneous checkouts using the last available use of a
limited coupon could both succeed (check-then-increment race).
Now: the increment is atomic and conditioned on the limit in a single
database operation (findOneAndUpdate with $expr), same pattern as every
wallet balance debit elsewhere in this app. If the limit was already hit
by the time this runs, the discount is simply not granted.

PART 2 - AI-powered live chat widget
New:     lib/supportBot.ts                (calls Claude with real store facts as its only knowledge)
New:     app/api/support/chat/route.ts    (chat endpoint, auto-creates a ticket on escalation)
Updated: components/SupportWidget.tsx     (was just a button to /support - now a real inline chat panel)

How it works:
- Floating chat bubble opens an inline panel (no page navigation).
- Every message is sent with full conversation history to Claude
  (claude-haiku-4-5-20251001 - fast/cheap, good for FAQ-style support).
- The bot ONLY knows the real facts about this store (funding via
  NeuraPay/Paga/PalmPay, refund policy, coupons, referrals, etc.) - it's
  explicitly instructed NOT to guess or invent policy.
- If a question needs a human (specific order/account issues, refund
  requests, anything outside its given facts), the bot says so and the
  backend automatically creates a support ticket with the full chat
  transcript, notifies you via Telegram (same as manual tickets), and
  tells the customer they're now connected to a human - answered from
  the existing /support ticket system, no new admin UI needed.
- If the visitor isn't logged in when escalation happens, they're
  prompted to log in (a ticket needs an account to attach to).

REQUIRES a new env var: ANTHROPIC_API_KEY
  Get one at https://console.anthropic.com (API Keys section).
  Add it to .env.local AND to Vercel's Environment Variables, same as
  your other secrets - never commit it.
  If this key is missing, the bot fails safe: every message immediately
  escalates to a human ticket instead of pretending to answer.

HOW TO USE:
1. Upload to repo root in Codespace.
2. unzip -o coupon-fix-and-chat-bot.zip -d .
   rm coupon-fix-and-chat-bot.zip
3. Add ANTHROPIC_API_KEY to .env.local (and Vercel) - see above.
4. npm run dev - test the chat bubble: ask an FAQ-type question (should
   answer directly), then ask something order-specific like "my order
   didn't arrive" (should escalate and create a ticket - check /admin/tickets).
5. git add lib/coupon.ts app/api/cart/checkout/route.ts lib/supportBot.ts app/api/support/chat/route.ts components/SupportWidget.tsx
   git commit -m "Fix coupon usage race condition; add AI-powered live chat widget"
   git push
