Forgot Password / Reset Password feature
==========================================
New:     app/api/auth/forgot-password/route.ts
New:     app/api/auth/reset-password/route.ts
New:     app/forgot-password/page.tsx
New:     app/reset-password/page.tsx
Updated: models/User.ts        (adds resetPasswordTokenHash + expiry fields)
Updated: lib/email.ts          (adds sendPasswordResetEmail)
Updated: app/login/page.tsx    (adds "Forgot password?" link)

How it works:
1. User clicks "Forgot password?" on login -> enters email on /forgot-password.
2. Backend ALWAYS returns the same generic success message, whether or not
   that email exists (prevents attackers probing which emails are
   registered - standard practice).
3. If the email exists: generates a random 32-byte token, stores only its
   SHA-256 HASH + a 1-hour expiry on the user (never the raw token, same
   principle as password hashing), emails a link containing the raw token.
4. User clicks the emailed link -> /reset-password?token=...&email=...
   -> enters a new password (min 8 chars, confirmed twice).
5. Backend re-hashes the submitted token and checks it matches + hasn't
   expired. If valid: sets the new password (hashed automatically by the
   existing pre-save hook in models/User.ts) and immediately clears the
   token so the same link can't be reused.

Rate limited on both routes (reuses lib/rateLimit.ts, same pattern as
login/register) to prevent abuse/spam and token brute-forcing.

REQUIRES: RESEND_API_KEY and NEXT_PUBLIC_SITE_URL to already be set in
your .env.local / Vercel env (you already have these from earlier).

HOW TO USE:
1. Upload to repo root in Codespace.
2. unzip -o forgot-password-feature.zip -d .
   rm forgot-password-feature.zip
3. npm run dev - test the full flow: Login page -> Forgot password ->
   enter your email -> check inbox -> click link -> set new password ->
   log in with the new password.
4. git add models/User.ts lib/email.ts app/login/page.tsx app/forgot-password/page.tsx app/reset-password/page.tsx app/api/auth/forgot-password/route.ts app/api/auth/reset-password/route.ts
   git commit -m "Add forgot password / reset password flow"
   git push
