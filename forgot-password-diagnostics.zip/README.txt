Diagnostic logging for forgot-password (debugging the "no email" report)
===========================================================================
Updated: app/api/auth/forgot-password/route.ts

No bug found in the email/rate-limit logic itself after tracing it
carefully - RESEND_API_KEY works (confirmed by other emails arriving),
domain is verified, and the code paths are correct. The most likely
explanation: the per-email limit (3 requests/hour) was hit from testing
this feature a few times already - past that limit, the route silently
skips sending while still showing the same "check your email" message
to prevent leaking account existence to an attacker. That's intentional,
but made it hard for YOU to tell what happened.

This update adds clear, distinct console.log lines at each silent branch:
  - rate-limited -> "[forgot-password] rate-limited, no email sent for X"
  - no account found -> "[forgot-password] no account found for X"
  - email actually sent -> "[forgot-password] email sent successfully to X"
  - email actually failed -> "[forgot-password] email send FAILED for X: <reason>"

These only appear in your Vercel function logs (Project -> Deployments ->
your deployment -> Functions/Logs, or `vercel logs` if you use the CLI) -
they never reach the browser, so the anti-enumeration security behavior
for real users is unchanged.

NEXT STEPS:
1. Deploy this.
2. Wait ~1 hour since your last test (to clear the per-email rate limit),
   OR just check Vercel's logs for your most recent attempt right now -
   it'll likely show the "rate-limited" line, confirming that's what
   happened.
3. Try forgot-password ONE more time and check the logs immediately -
   it should now show either "email sent successfully" (problem solved,
   check spam folder too) or a specific FAILED reason we can act on.

HOW TO USE:
1. Upload to repo root in Codespace.
2. unzip -o forgot-password-diagnostics.zip -d .
   rm forgot-password-diagnostics.zip
3. git add app/api/auth/forgot-password/route.ts
   git commit -m "Add diagnostic logging to forgot-password route"
   git push
